MZSMP 2 — Página web
====================

ARCHIVOS
- index.html: estructura y contenido de la página.
- style.css: diseño adaptable, estética oscura, efectos y animaciones.
- script.js: animaciones al desplazarse, menú móvil y año automático.

ANTES DE PUBLICAR
1. Abre index.html en tu navegador para revisar la página.
2. El botón de Discord usa la invitación https://discord.gg/vfuMRgraB.
3. Si la invitación cambia, busca esa URL en index.html y reemplázala.
4. El sitio dice “Próximamente” y no muestra una fecha de lanzamiento inventada.

PUBLICAR GRATIS CON GITHUB PAGES
1. Crea o inicia sesión en https://github.com/
2. Crea un repositorio público llamado mzsmp2-web.
3. Sube index.html, style.css y script.js a la raíz del repositorio.
4. En el repositorio, entra a Settings → Pages.
5. En “Build and deployment”, elige “Deploy from a branch”.
6. Selecciona la rama “main” y la carpeta “/(root)”; guarda.
7. Espera a que GitHub publique el sitio. La URL normalmente será:
   https://TU-USUARIO.github.io/mzsmp2-web/
   Cambia TU-USUARIO por tu nombre de usuario de GitHub.

ALTERNATIVA: NETLIFY
1. Entra a https://app.netlify.com/
2. Crea una cuenta e inicia sesión.
3. Usa la opción para añadir/desplegar un sitio manualmente y arrastra la carpeta
   que contiene los tres archivos.
4. Netlify te dará una URL pública. Puedes cambiar el nombre del subdominio
   desde la configuración si está disponible.

NOTAS
- No necesita servidor ni base de datos: es una página estática.
- La fuente pixelada se carga desde Google Fonts; si no hay conexión, se usa
  una fuente monoespaciada de respaldo.
- Minecraft es una marca de Mojang/Microsoft. Esta es una página comunitaria
  no oficial y no está afiliada a Mojang/Microsoft.
